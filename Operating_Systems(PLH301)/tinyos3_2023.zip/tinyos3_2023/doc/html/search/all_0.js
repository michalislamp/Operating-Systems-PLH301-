var searchData=
[
  ['_5f_5frs_5fglobals_0',['__rs_globals',['../struct____rs__globals.html',1,'']]]
];
