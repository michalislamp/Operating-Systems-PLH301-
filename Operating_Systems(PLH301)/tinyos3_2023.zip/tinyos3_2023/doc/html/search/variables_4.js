var searchData=
[
  ['exited_5flist_504',['exited_list',['../structprocess__control__block.html#afddb936103b136214462e1ed870c4c70',1,'process_control_block']]],
  ['exited_5fnode_505',['exited_node',['../structprocess__control__block.html#a9e0d93783a89bd92f39243353f04a27e',1,'process_control_block']]],
  ['exitval_506',['exitval',['../structprocess__control__block.html#add9b4f6d506a3538be7b53411e94fd28',1,'process_control_block']]]
];
